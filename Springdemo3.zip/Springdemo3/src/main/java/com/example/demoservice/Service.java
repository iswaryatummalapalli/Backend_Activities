package com.example.demoservice;

public class Service {
	public String hello() {
		return "hello  hai good ";
	}
}
